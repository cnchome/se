<?php

	// include Ohio components
	include_once get_template_directory() . '/inc/framework/components/helper.php';
	include_once get_template_directory() . '/inc/framework/components/options_cache.php';
	include_once get_template_directory() . '/inc/framework/components/options.php';
	include_once get_template_directory() . '/inc/framework/components/settings.php';
	include_once get_template_directory() . '/inc/framework/components/buffer.php';
	include_once get_template_directory() . '/inc/framework/components/layout.php';
	include_once get_template_directory() . '/inc/framework/components/object_parser.php';
