<?php

// Silence is golden.